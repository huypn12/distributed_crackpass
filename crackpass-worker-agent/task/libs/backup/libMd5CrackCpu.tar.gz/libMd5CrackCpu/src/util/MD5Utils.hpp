#include "Vector.hpp"

DigestToVct( const std::string md5str, Vct4Uint32_t &vct );
VctToDigest( const Vct4Uint32_t vct, std::string &md5str );


