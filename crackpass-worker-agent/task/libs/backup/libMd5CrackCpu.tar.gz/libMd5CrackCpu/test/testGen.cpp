
// Testing plaintext gen mechanizm
// ascii only
int genBaseById(
        int32_t dictId,
        char *charsetStr, size_t charsetLen
        size_t baseLen
        )
{
    uint32_t vec[ 16 ];
    // Less than 16 character input
    for( int length = 1; length < baseLen; ) {

        for( int  );

        length += 4;
    }

}
