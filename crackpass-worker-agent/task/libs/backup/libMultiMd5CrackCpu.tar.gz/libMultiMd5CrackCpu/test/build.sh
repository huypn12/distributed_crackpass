
g++ -g -std=c++11 -O3 -Wall -fPIC -lboost_system -lboost_thread -I../include main.cpp ../src/*.cpp ../src/kernel/*.cpp 
